import React, { useState } from 'react';
import Header from './components/Header';
import About from './components/About';
import Experience from './components/Experience';
import Skills from './components/Skills';
import Education from './components/Education';
import Projects from './components/Projects';
import Footer from './components/Footer';
import ProjectDetailModal from './components/ProjectDetailModal';
import type { Project } from './types';

const App: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
    document.body.style.overflow = 'hidden';
  };

  const handleCloseModal = () => {
    setSelectedProject(null);
    document.body.style.overflow = 'auto';
  };

  return (
    <div className="bg-slate-50 min-h-screen font-sans text-slate-700">
      <main className="container mx-auto max-w-5xl py-8 px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 md:p-12 space-y-16">
          <Header />
          <About />
          <Experience />
          <Skills />
          <Education />
          <Projects onSelectProject={handleSelectProject} />
        </div>
        <Footer />
      </main>
      <ProjectDetailModal project={selectedProject} onClose={handleCloseModal} />
    </div>
  );
};

export default App;
